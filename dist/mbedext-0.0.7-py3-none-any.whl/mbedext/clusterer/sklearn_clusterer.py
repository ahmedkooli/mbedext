class SklearnClusterer:
    def __init__(self) -> None:
        pass